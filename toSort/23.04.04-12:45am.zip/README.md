# theWriterList

# theWriterList is supposed to be a simple Python database program meant to help me learn python and databases.
